"""Trim Trailing Whitespace — a real DariaOS plugin. Called as:
    python plugin.py <hook_name> <json_payload>
by extensions.plugin_manager.PluginHandle.call_hook, one-shot per hook dispatch.
Prints a JSON object to stdout; extensions.plugin_manager reads it back.
"""
import json
import sys


def main() -> None:
    hook_name = sys.argv[1]
    payload = json.loads(sys.argv[2])

    if hook_name == "files:before-write":
        content = payload.get("content", "")
        lines = content.split("\n")
        trimmed = "\n".join(line.rstrip() for line in lines)
        print(json.dumps({"content": trimmed}))
        return

    print(json.dumps({}))


if __name__ == "__main__":
    main()
