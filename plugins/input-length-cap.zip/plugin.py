"""Input Length Cap — a real DariaOS plugin on the chat:before-reply hook. Called as:
    python plugin.py <hook_name> <json_payload>
by extensions.plugin_manager.PluginHandle.call_hook, one-shot per hook dispatch.
Prints a JSON object to stdout; extensions.plugin_manager reads it back.

Caps an overly long pasted user message before it reaches the LLM's own context window
(a giant paste can otherwise crowd out the actual conversation history/system prompt).
"""
import json
import sys

MAX_CHARS = 4000


def main() -> None:
    hook_name = sys.argv[1]
    payload = json.loads(sys.argv[2])

    if hook_name == "chat:before-reply":
        text = payload.get("text", "")
        if len(text) > MAX_CHARS:
            text = text[:MAX_CHARS].rsplit(" ", 1)[0] + "… [обрезано, сообщение было слишком длинным]"
        print(json.dumps({"text": text}))
        return

    print(json.dumps({}))


if __name__ == "__main__":
    main()
