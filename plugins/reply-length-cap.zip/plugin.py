"""Reply Length Cap — a real DariaOS plugin on the chat:after-reply hook. Called as:
    python plugin.py <hook_name> <json_payload>
by extensions.plugin_manager.PluginHandle.call_hook, one-shot per hook dispatch.
Prints a JSON object to stdout; extensions.plugin_manager reads it back.

Truncates an absurdly long reply (a runaway/looping model, or a broken prompt) to a
safe maximum length instead of letting it render as a wall of text.
"""
import json
import sys

MAX_CHARS = 1200


def main() -> None:
    hook_name = sys.argv[1]
    payload = json.loads(sys.argv[2])

    if hook_name == "chat:after-reply":
        text = payload.get("text", "")
        if len(text) > MAX_CHARS:
            text = text[:MAX_CHARS].rsplit(" ", 1)[0] + "…"
        print(json.dumps({"text": text}))
        return

    print(json.dumps({}))


if __name__ == "__main__":
    main()
