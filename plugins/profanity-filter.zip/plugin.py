"""Profanity Filter — a real DariaOS plugin on the chat:after-reply hook. Called as:
    python plugin.py <hook_name> <json_payload>
by extensions.plugin_manager.PluginHandle.call_hook, one-shot per hook dispatch.
Prints a JSON object to stdout; extensions.plugin_manager reads it back.

Masks any whole word from wordlist.txt (one word per line, case-insensitive, real
word-boundary matching so it doesn't clip inside unrelated words) in Daria's own reply.
Ships with a short, mild sample list — edit wordlist.txt in this plugin's own installed
directory to filter stronger language; the matching mechanism itself is the real feature.
"""
import json
import re
import sys
from pathlib import Path


def load_wordlist() -> list[str]:
    path = Path(__file__).parent / "wordlist.txt"
    if not path.exists():
        return []
    return [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def mask(text: str, words: list[str]) -> str:
    for word in words:
        pattern = re.compile(r"\b" + re.escape(word) + r"\b", re.IGNORECASE)
        text = pattern.sub("*" * len(word), text)
    return text


def main() -> None:
    hook_name = sys.argv[1]
    payload = json.loads(sys.argv[2])

    if hook_name == "chat:after-reply":
        text = payload.get("text", "")
        print(json.dumps({"text": mask(text, load_wordlist())}))
        return

    print(json.dumps({}))


if __name__ == "__main__":
    main()
